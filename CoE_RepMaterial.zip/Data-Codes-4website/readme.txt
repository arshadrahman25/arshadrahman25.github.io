

Estimation Codes for the book chapter, ``Binary and Ordinal Probit Regression: Applications to Public Opinion on Marijuana Legalization in the United States''. 
***************************************************************************************************************************

Download all the files (Feb14Data.xlsx, Mar13Data.xlsx, ProbitScript.m, OrdinalProbitScript.m, and ordinalMLE.m) and save them in a folder on your desktop.

1) To obtain results for the Probit model, open the file "ProbitScript.m" and press the run button in Matlab.
2) To obtain results for the ordinal Probit model, open the file "OrdinalProbitScript.m" and press the run button in Matlab.

Note: If you are not opening the script file from within the folder in a new Matlab session, please set the path of the folder. 

***************************************************************************************************************************






