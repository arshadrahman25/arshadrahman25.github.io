
% Probit Model

%% Application: Marijuana Study

clear all
clc
[data, text] = xlsread('Mar13Data.xlsx','CleanedDataMar13','A2:M1213');

age            = data(:,1);          % Age of the respondent
logage         = log(age);
nMember        = data(:,8);          % No of members in the household

n              = size(age,1);

logageSummary = [mean(logage) std(logage)]

nMemberSummary = [mean(nMember) std(nMember)]

%% Response variable
opinion        = zeros(n,1);
for i = 1:n
    if strcmp(text(i,1),'Yes, legal')    
        opinion(i,1) = 1;                 % favor legalization = 1
    end
end
tabulate(opinion)
%% Covariates

%---------------------------------
% Pastuse
pastuse        = zeros(n,1);              % Used marijuana in the past = 1
for i = 1:n
    if strcmp(text(i,2),'Yes')    
        pastuse(i,1) = 1;                 
    end
end
disp('        Past Use')
disp('----------------------------')
tabulate(pastuse)

%---------------------------------
%% Religion (We are not using Religion in the Analysis)

religion       = nominal(text(:,3));

% religion = mergelevels(religion,{'Agnostic (not sure if there is a God)', ...
%     'Atheist (do not believe in God)', 'Nothing in particular', '(VOL) Unitarian (Universalist)'},'liberal');
% 
% religion = mergelevels(religion,{'Buddhist', 'Hindu', 'Muslim (Islam)','Jewish (Judaism)',...
%             'Mormon (Church of Jesus Christ of Latter-day Saints/LDS)',...
%             'Orthodox (Greek, Russian, or some other orthodox church)'},'conservative');
%         
% getlevels(religion)

protestant       = zeros(n,1);
romanCatholic    = zeros(n,1);
christian        = zeros(n,1);
conservative     = zeros(n,1);
liberal          = zeros(n,1);

for i = 1:n
    if strcmp(text(i,3),'Protestant (Baptist, Methodist, Non-denominational, Lutheran, Presbyterian, Pentecostal, Episcopalian, etc.)')    
        protestant(i,1) = 1;                 
    elseif strcmp(text(i,3),'Roman Catholic (Catholic)') 
        romanCatholic(i,1) = 1;
    elseif strcmp(text(i,3),'(VOL) Christian') 
        christian(i,1) = 1;    
    elseif strcmp(text(i,3),'Agnostic (not sure if there is a God)')||...
           strcmp(text(i,3),'Atheist (do not believe in God)')||...
           strcmp(text(i,3),'Nothing in particular')||...
           strcmp(text(i,3),'(VOL) Unitarian (Universalist)');
        liberal(i,1) = 1;
    elseif strcmp(text(i,3),'Buddhist')||strcmp(text(i,3),'Hindu')||...
           strcmp(text(i,3),'Muslim (Islam)')||strcmp(text(i,3),'Jewish (Judaism)')||...
           strcmp(text(i,3),'Mormon (Church of Jesus Christ of Latter-day Saints/LDS)')||...
           strcmp(text(i,3),'Orthodox (Greek, Russian, or some other orthodox church)')
        conservative(i,1) = 1;
    end
end


disp('________ Protestant ________')
tabulate(protestant)

disp('________ Roman Catholic ________')
tabulate(romanCatholic)

disp('________ Christian ________')
tabulate(christian)

disp('________ Conservative ________')
tabulate(conservative)

disp('________ liberal ________')
tabulate(liberal)


%---------------------------------
%% Gender

male            = zeros(n,1);              % Male = 1
for i = 1:n
    if strcmp(text(i,4),'Male')    
        male(i,1) = 1;                 
    end
end
disp('___________  Male ________  ')
tabulate(male)

%---------------------------------
%% Education

education    = text(:,6);
% education    = nominal(education);
% education    = mergelevels(education,{'Less than HS', 'HS Incomplete'},'hsIncomplete');
% education    = mergelevels(education,{'Some college','Associate Degree'},'lessThanBachelors');
% education    = mergelevels(education,{'Postgraduate Degree','Some
% Postgraduate'},'postBachelors');


HSandBelow         = zeros(n,1);
lessThanBachelors  = zeros(n,1);   
BachelorsandAbove  = zeros(n,1);


for i = 1:n
    if strcmp( text(i,6),'Less than HS')||strcmp(text(i,6),'HS Incomplete')||...               
    strcmp(text(i,6),'HS') 
        HSandBelow(i,1) = 1;
    elseif strcmp(text(i,6),'Some College')||strcmp(text(i,6),'Associate Degree')
        lessThanBachelors(i,1) = 1;
    elseif strcmp(text(i,6),'Four year college')||strcmp(text(i,6),'Postgraduate Degree')...
        ||strcmp(text(i,6),'Some Postgraduate')
        BachelorsandAbove(i,1) = 1;
    end
end

disp('_____ High School and Below _________')
tabulate(HSandBelow)

disp('_____ less than Bachelors _________')
tabulate(lessThanBachelors)

disp('_____ Bachelors and Above _________')
tabulate(BachelorsandAbove)
%---------------------------------
%% Race

% race    = nominal(race);
% race    = mergelevels(race,{'Asian', 'Hispanic','Native American','Other Race','Pacific Islander'},'AllOther');

race    = text(:,7);
white    = zeros(n,1);
black    = zeros(n,1);
allOther = zeros(n,1);

for i = 1:n
    if strcmp(text(i,7),'White')    
        white(i,1) = 1;                 
    elseif strcmp(text(i,7),'Black or African-American') 
        black(i,1) = 1;
    else
        allOther(i,1) = 1;
    end
end
tabulate(race)

disp('________ White ________')
tabulate(white)

disp('________ Black ________')
tabulate(black)

disp('________ All Other ________')
tabulate(allOther)
%---------------------------------
%% Marital Status

% maritalStatus = nominal(maritalStatus);
% maritalStatus = mergelevels(maritalStatus,{'Divorced', 'Separated','Widowed'},'uncouple');
% maritalStatus = mergelevels(maritalStatus,{'Married', 'Living with a partner'},'couple');

maritalStatus = text(:,8);
single     = zeros(n,1);
uncouple   = zeros(n,1);
couple     = zeros(n,1);            % base category

for i = 1:n
    if strcmp(text(i,8),'Never been married')    
        single(i,1) = 1;                 
    elseif strcmp(text(i,8),'Divorced')||strcmp(text(i,8),'Separated')||strcmp(text(i,8),'Widowed') 
        uncouple(i,1) = 1;
    elseif strcmp(text(i,8),'Married')||strcmp(text(i,8),'Living with a partner') 
        couple(i) = 1;
    end
end

disp('____________ Marital Status ___________')
tabulate(maritalStatus)

disp('____________ Single ___________')
tabulate(single)

disp('____________ Uncouple ___________')
tabulate(uncouple)

disp('____________ Couple ___________')
tabulate(couple)
%---------------------------------
%% Parent
parent         = zeros(n,1);              % Parent or guardian of any children under 18 = 1
for i = 1:n
    if strcmp(text(i,9),'Yes')    
        parent(i,1) = 1;                 
    end
end
disp('________ Parent _________')
tabulate(parent)

%---------------------------------

%% Income as continous variable


incomeC = zeros(n,1);
for i = 1:n

    if strcmp(text(i,10),'Less than $10,000')
        incomeC(i,1)  = 5000;
    elseif strcmp(text(i,10),'10 to under $20,000')
        incomeC(i,1)  = 15000;
    elseif strcmp(text(i,10),'20 to under $30,000')
        incomeC(i,1)  = 25000;
    elseif strcmp(text(i,10),'30 to under $40,000')
        incomeC(i,1)  = 35000;
    elseif strcmp(text(i,10),'40 to under $50,000')
        incomeC(i,1)  = 45000;
    elseif strcmp(text(i,10),'50 to under $75,000')
        incomeC(i,1)  = 63500;
    elseif strcmp(text(i,10),'75 to under $100,000')
        incomeC(i,1)  = 87500;
    elseif strcmp(text(i,10),'100 to under $150,000')
        incomeC(i,1)  = 125000;
    elseif strcmp(text(i,10),'$150,000 or more')
        incomeC(i,1)  = 150000;
    end
end
    
logIncomeC  = log(incomeC);
unique(logIncomeC)

logIncomeCSummary = [mean(logIncomeC) std(logIncomeC)]
%-------------------------------------------------------------------    
%% Party Affiliation

party              = text(:,11);
democrat           = zeros(n,1);
republican         = zeros(n,1);
independentOthers  = zeros(n,1);    % independent and others

for i = 1:n
    if strcmp(text(i,11),'Democrat')
        democrat(i,1) = 1;                 
    elseif strcmp(text(i,11),'Republican') 
        republican(i,1) = 1;
    elseif strcmp(text(i,11),'Independent')||strcmp(text(i,11),'(VOL) Other party')...
            ||strcmp(text(i,11),'(VOL) No preference') 
        independentOthers(i,1) = 1;
    end
end

disp('________ Democrat ________')
tabulate(democrat)

disp('________ Republican ________')
tabulate(republican)

disp('________ Independent and Others ________')
tabulate(independentOthers)


%----------------------------------------------------------------------------------------------------------
%% State

state              = text(:,13);
totalProhibition   = zeros(n,1);
someRelaxation     = zeros(n,1);

for i = 1:n
    if strcmp(text(i,13),'Alabama')||strcmp(text(i,13),'Arkansas')||strcmp(text(i,13),'Florida')...
            ||strcmp(text(i,13),'Georgia')||strcmp(text(i,13),'Idaho')||strcmp(text(i,13),'Indiana')...
            ||strcmp(text(i,13),'Iowa')||strcmp(text(i,13),'Kansas')||strcmp(text(i,13),'Kentucky')...
            ||strcmp(text(i,13),'Louisiana')||strcmp(text(i,13),'Minnesota')||strcmp(text(i,13),'Mississippi')...
            ||strcmp(text(i,13),'Missouri')||strcmp(text(i,13),'Nebraska')||strcmp(text(i,13),'New York')...
            ||strcmp(text(i,13),'North Carolina')||strcmp(text(i,13),'North Dakota')||strcmp(text(i,13),'Ohio')...
            ||strcmp(text(i,13),'Oklahoma')||strcmp(text(i,13),'Pennsylvania')||strcmp(text(i,13),'South Carolina')...
            ||strcmp(text(i,13),'South Dakota')||strcmp(text(i,13),'Tennessee')||strcmp(text(i,13),'Texas')...
            ||strcmp(text(i,13),'Utah')||strcmp(text(i,13),'Virginia')||strcmp(text(i,13),'West Virginia')...
            ||strcmp(text(i,13),'Wisconsin')||strcmp(text(i,13),'Wyoming')||strcmp(text(i,13),'Illinois')...
            ||strcmp(text(i,13),'New Hampshire')
        totalProhibition(i,1)= 1;
        
        
    elseif strcmp(text(i,13),'Alaska')||strcmp(text(i,13),'Arizona')||strcmp(text(i,13),'California')...
            ||strcmp(text(i,13),'Colorado')||strcmp(text(i,13),'Connecticut')||strcmp(text(i,13),'Delaware')...
            ||strcmp(text(i,13),'Hawaii')||strcmp(text(i,13),'Maine')...
            ||strcmp(text(i,13),'Maryland')||strcmp(text(i,13),'Massachusetts')||strcmp(text(i,13),'Michigan')...
            ||strcmp(text(i,13),'Montana')||strcmp(text(i,13),'Nevada')...
            ||strcmp(text(i,13),'New Jersey')||strcmp(text(i,13),'New Mexico')||strcmp(text(i,13),'Oregon')...
            ||strcmp(text(i,13),'Rhode Island')||strcmp(text(i,13),'Vermont')||strcmp(text(i,13),'Washington')...
            ||strcmp(text(i,13),'Washington DC')
        someRelaxation(i,1)= 1;
    end
end

disp('________ totalProhibition ________')
tabulate(totalProhibition)

disp('________ someRelaxation ________')
tabulate(someRelaxation)

%--------------------------------------------------------------------------
% Estimating Different Models
%--------------------------------------------------------------------------
%% Opinion 

y = opinion;

%[ gender age maritalStatus parent nMember income pastuse education race religion party]

%% Intercept Model

[betaProbit0, devProbit0, statsProbit0] = glmfit(ones(n,1),y,'binomial','link','probit', 'constant','off');

  rowlabels0 = char('intercept');

  

     fprintf('             Results from Intercept Probit Model   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('             Coeff   Std Err   t-values \n')
     fprintf('            ________  ________  _________ \n')  
     fprintf(' %s  % 4.2f  % 8.2f  % 8.2f  \n', rowlabels0,...
             betaProbit0, statsProbit0.se, statsProbit0.t)
    

         predProb0 = glmval(betaProbit0,ones(n,1),'probit');
     
%--------------------------------------------------------------------------
%                       Model0 Diagnostics
%--------------------------------------------------------------------------
hit0 = zeros(n,1);

for i=1:n
    if (predProb0(i,1) > 0.5 && y(i,1)==1)||(predProb0(i,1) <= 0.5 && y(i,1)==0)
        hit0(i,1) = 1;
    end
end

hitrate0 = (sum(hit0)/n)*100

% Log Likelihood of the Null Model

lnpdf0  = zeros(n,1);
mu0     = ones(n,1)*betaProbit0;

for i = 1:n
    meani = mu0(i);
    if y(i)==1
        lnpdf0(i) = log( normcdf(meani,0,1));
    elseif y(i)==0
        lnpdf0(i) = log(1 - normcdf(meani,0,1));
    end
end

sumlogLikelihood0  = sum(lnpdf0)

%% Model 1
% protestant       = zeros(n,1);
% romanCatholic    = zeros(n,1);
% christian        = zeros(n,1);
% conservative     = zeros(n,1);
% liberal          = zeros(n,1);

x1   = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
       nMember someRelaxation ];


rowlabels1  = char('intercept','logage','logIncomeC','pastuse','male',...
                   'BachelorsandAbove','lessThanBachelors','Household Size',...
                   'someRelaxation');

[betaProbit1, devProbit1, statsProbit1] = glmfit(x1,y,'binomial','link','probit');

     fprintf('             Results from Model1   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('                    Coeff   Std Err   t-values \n')
     fprintf('                   ________  ________  _________ \n')
 
     for i = 1:size(x1,2)+1
         fprintf(' %s  % 4.2f  % 8.2f  % 8.2f  \n', rowlabels1(i,:),...
             betaProbit1(i), statsProbit1.se(i), statsProbit1.t(i))
     end

     predProb1 = glmval(betaProbit1,x1,'probit');

%--------------------------------------------------------------------------
%                       Model1 Diagnostics
%--------------------------------------------------------------------------
hit1 = zeros(n,1);

for i=1:n
    if (predProb1(i,1) > 0.5 && y(i,1)==1)||(predProb1(i,1) <= 0.5 && y(i,1)==0)
        hit1(i,1) = 1;
    end
end
hitrate1 = (sum(hit1)/n)*100


lnpdf1  = zeros(n,1);
mu1     = [ones(n,1) x1]*betaProbit1;

for i = 1:n
    mean1i = mu1(i);
    if y(i)==1
        lnpdf1(i) = log( normcdf(mean1i,0,1));
    elseif y(i)==0
        lnpdf1(i) = log(1 - normcdf(mean1i,0,1));
    end
end

sumlogLikelihood1  = sum(lnpdf1)

McFaddenRsquare1 = 1 -(sumlogLikelihood1/sumlogLikelihood0)

chisquareTest1   = - 2*(sumlogLikelihood0 - sumlogLikelihood1)

% Compare with chisquare(8) = 15.51

%% Model 2

x2   = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
       nMember someRelaxation black allOther];


rowlabels2  = char('intercept','logage','logIncomeC','pastuse','male',...
                   'BachelorsandAbove','lessThanBachelors','Household Size',...
                   'someRelaxation','black','allOther');

[betaProbit2, devProbit2, statsProbit2] = glmfit(x2,y,'binomial','link','probit');

     fprintf('             Results from Model2   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('                    Coeff   Std Err   t-values \n')
     fprintf('                   ________  ________  _________ \n')
 
     for i = 1:size(x2,2)+1
         fprintf(' %s  % 4.2f  % 8.2f  % 8.2f  \n', rowlabels2(i,:),...
             betaProbit2(i), statsProbit2.se(i), statsProbit2.t(i))
     end

     predProb2 = glmval(betaProbit2,x2,'probit');
     
%--------------------------------------------------------------------------
%                       Model2 Diagnostics
%--------------------------------------------------------------------------
hit2 = zeros(n,1);

for i=1:n
    if (predProb2(i,1) > 0.5 && y(i,1)==1)||(predProb2(i,1) <= 0.5 && y(i,1)==0)
        hit2(i,1) = 1;
    end
end
hitrate2 = (sum(hit2)/n)*100


lnpdf2  = zeros(n,1);
mu2     = [ones(n,1) x2]*betaProbit2;

for i = 1:n
    mean2i = mu2(i);
    if y(i)==1
        lnpdf2(i) = log( normcdf(mean2i,0,1));
    elseif y(i)==0
        lnpdf2(i) = log(1 - normcdf(mean2i,0,1));
    end
end

sumlogLikelihood2  = sum(lnpdf2)

McFaddenRsquare2 = 1 -(sumlogLikelihood2/sumlogLikelihood0)

chisquareTest2   = - 2*(sumlogLikelihood0 - sumlogLikelihood2)

% Compare with chisquare(10) = 18.307


%% Model 3

x3   = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
       nMember someRelaxation black allOther democrat independentOthers];


rowlabels3  = char('intercept','logage','logIncomeC','pastuse','male',...
                   'BachelorsandAbove','lessThanBachelors','Household Size',...
                   'someRelaxation','black','allOther','democrat','independentOthers');

[betaProbit3, devProbit3, statsProbit3] = glmfit(x3,y,'binomial','link','probit');

     fprintf('             Results from Model3   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('                    Coeff   Std Err   t-values \n')
     fprintf('                   ________  ________  _________ \n')
 
     for i = 1:size(x3,2)+1
         fprintf(' %s  % 4.2f  % 8.2f  % 8.2f  \n', rowlabels3(i,:),...
             betaProbit3(i), statsProbit3.se(i), statsProbit3.t(i))
     end

     predProb3 = glmval(betaProbit3,x3,'probit');
     
%--------------------------------------------------------------------------
%                       Model3 Diagnostics
%--------------------------------------------------------------------------
hit3 = zeros(n,1);

for i=1:n
    if (predProb3(i,1) > 0.5 && y(i,1)==1)||(predProb3(i,1) <= 0.5 && y(i,1)==0)
        hit3(i,1) = 1;
    end
end
hitrate3 = (sum(hit3)/n)*100


lnpdf3  = zeros(n,1);
mu3     = [ones(n,1) x3]*betaProbit3;

for i = 1:n
    mean3i = mu3(i);
    if y(i)==1
        lnpdf3(i) = log( normcdf(mean3i,0,1));
    elseif y(i)==0
        lnpdf3(i) = log(1 - normcdf(mean3i,0,1));
    end
end

sumlogLikelihood3  = sum(lnpdf3)

McFaddenRsquare3 = 1 -(sumlogLikelihood3/sumlogLikelihood0)

chisquareTest3   = - 2*(sumlogLikelihood0 - sumlogLikelihood3)

% Compare with chisquare(12) = 21.03

%% Model 4


x4   = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
       nMember someRelaxation black allOther democrat independentOthers ...
       romanCatholic christian conservative liberal ];


rowlabels1  = char('intercept','logage','logIncomeC','pastuse','male',...
                   'BachelorsandAbove','lessThanBachelors','Household Size',...
                   'someRelaxation','black','allOther','democrat','independentOthers',...
                   'romanCatholic','christian','conservative','liberal');

[betaProbit4, devProbit4, statsProbit4] = glmfit(x4,y,'binomial','link','probit');

     fprintf('             Results from Model4   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('                    Coeff   Std Err   t-values \n')
     fprintf('                   ________  ________  _________ \n')
 
     for i = 1:size(x4,2)+1
         fprintf(' %s  % 4.2f  % 8.2f  % 8.2f  \n', rowlabels1(i,:),...
             betaProbit4(i), statsProbit4.se(i), statsProbit4.t(i))
     end

     predProb4 = glmval(betaProbit4,x4,'probit');
     
%--------------------------------------------------------------------------
%                       Model4 Diagnostics
%--------------------------------------------------------------------------
hit4 = zeros(n,1);

for i=1:n
    if (predProb4(i,1) > 0.5 && y(i,1)==1)||(predProb4(i,1) <= 0.5 && y(i,1)==0)
        hit4(i,1) = 1;
    end
end
hitrate4 = (sum(hit4)/n)*100


lnpdf4  = zeros(n,1);
mu4     = [ones(n,1) x4]*betaProbit4;

for i = 1:n
    mean4i = mu4(i);
    if y(i)==1
        lnpdf4(i) = log( normcdf(mean4i,0,1));
    elseif y(i)==0
        lnpdf4(i) = log(1 - normcdf(mean4i,0,1));
    end
end

sumlogLikelihood4  = sum(lnpdf4)

McFaddenRsquare4 = 1 -(sumlogLikelihood4/sumlogLikelihood0)

chisquareTest4   = - 2*(sumlogLikelihood0 - sumlogLikelihood4)

% Compare with chisquare(16) = 26.30

%% Covariate effects
 
% (1) increasing age by 10 years.

% x4   = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
%        nMember someRelaxation black allOther democrat independentOthers ...
%        romanCatholic christian conservative liberal ];


xnewage   = [log(age+10) logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
             nMember someRelaxation black allOther democrat independentOthers ...
             romanCatholic christian conservative liberal];  
         
meanAgeCE = mean(glmval(betaProbit4,xnewage,'probit') - glmval(betaProbit4,x4,'probit'));

% (2) Past Use

xPastUse   = [logage logIncomeC ones(n,1) male BachelorsandAbove lessThanBachelors ...
              nMember someRelaxation black allOther democrat independentOthers ...
              romanCatholic christian conservative liberal];  

xNoPastUse = [logage logIncomeC zeros(n,1) male BachelorsandAbove lessThanBachelors ...
              nMember someRelaxation black allOther democrat independentOthers ...
              romanCatholic christian conservative liberal];  
         
meanPastUseCE   = mean(glmval(betaProbit4,xPastUse,'probit') - glmval(betaProbit4,xNoPastUse,'probit'));

% (3)  Male 

xnewMale     = [logage logIncomeC pastuse ones(n,1) BachelorsandAbove lessThanBachelors ...
                nMember someRelaxation black allOther democrat independentOthers ...
                romanCatholic christian conservative liberal];  
          
xFemale      = [logage logIncomeC pastuse zeros(n,1) BachelorsandAbove lessThanBachelors ...
                nMember someRelaxation black allOther democrat independentOthers ...
                romanCatholic christian conservative liberal];  

meanMaleCE   = mean(glmval(betaProbit4,xnewMale,'probit') - glmval(betaProbit4,xFemale,'probit'));

% (4) Bachelors and Above

xBachelorsandAbove   = [logage logIncomeC pastuse male ones(n,1) lessThanBachelors ...
                        nMember someRelaxation black allOther democrat independentOthers ...
                        romanCatholic christian conservative liberal]; 

xBaseEduc1   = [logage logIncomeC pastuse male zeros(n,1) lessThanBachelors ...
                nMember someRelaxation black allOther democrat independentOthers ...
                romanCatholic christian conservative liberal];
            
meanBachelorsandAboveCE   = mean(glmval(betaProbit4,xBachelorsandAbove,'probit') - glmval(betaProbit4,xBaseEduc1,'probit'));

% (5) Bachelors and Below

xBelowBachelors   = [logage logIncomeC pastuse male BachelorsandAbove ones(n,1) ...
                     nMember someRelaxation black allOther democrat independentOthers ...
                     romanCatholic christian conservative liberal];

xBaseEduc2   = [logage logIncomeC pastuse male BachelorsandAbove zeros(n,1) ...
                nMember someRelaxation black allOther democrat independentOthers ...
                romanCatholic christian conservative liberal];

meanBelowBachelorsCE   = mean(glmval(betaProbit4,xBelowBachelors,'probit') - glmval(betaProbit4,xBaseEduc2,'probit'));
        
% (6) Democrat

xDemocrat      = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther ones(n,1) independentOthers ...
                  romanCatholic christian conservative liberal]; 

xNoDemocrat    = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther zeros(n,1) independentOthers ...
                  romanCatholic christian conservative liberal];
              
meanDemocratCE = mean(glmval(betaProbit4,xDemocrat,'probit') - glmval(betaProbit4,xNoDemocrat,'probit'));

% (7) Other Parties

xOtherParties  = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther democrat ones(n,1) ...
                  romanCatholic christian conservative liberal]; 

xNoOtherParties    = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther democrat zeros(n,1) ...
                  romanCatholic christian conservative liberal];
              
meanOtherPartiesCE = mean(glmval(betaProbit4,xOtherParties,'probit') - glmval(betaProbit4,xNoOtherParties,'probit'));

% (8) Roman Catholic

xRomanCatholic  = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther democrat independentOthers ...
                  ones(n,1) christian conservative liberal]; 

xNoRomanCatholic  = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther democrat independentOthers ...
                  zeros(n,1) christian conservative liberal];
              
meanRomanCatholicCE = mean(glmval(betaProbit4,xRomanCatholic,'probit') - glmval(betaProbit4,xNoRomanCatholic,'probit'));


% (9) Conservative

xConservative  = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther democrat independentOthers ...
                  romanCatholic christian ones(n,1) liberal]; 

xNoConservative  = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther democrat independentOthers ...
                  romanCatholic christian zeros(n,1) liberal]; 
              
meanConservativeCE = mean(glmval(betaProbit4,xConservative,'probit') - glmval(betaProbit4,xNoConservative,'probit'));

% (10) Liberal

xLiberal       = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther democrat independentOthers ...
                  romanCatholic christian conservative ones(n,1)]; 

xNoLiberal     = [logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                  nMember someRelaxation black allOther democrat independentOthers ...
                  romanCatholic christian conservative zeros(n,1)];
              
meanLiberalCE = mean(glmval(betaProbit4,xLiberal,'probit') - glmval(betaProbit4,xNoLiberal,'probit'));




%% Covariate Effects in a Table
%--------------------------------------------------------------------------

rowlabelsCE  = char('Age,10 years','Past Use','Male','Bachelors and Above',...
    'Below Bachelors','Democrat','OtherParties','Roman Catholic','Conservative','Liberal');
                  
meanCE = [meanAgeCE meanPastUseCE meanMaleCE  meanBachelorsandAboveCE meanBelowBachelorsCE ...
          meanDemocratCE meanOtherPartiesCE meanRomanCatholicCE meanConservativeCE meanLiberalCE]';

                  
     fprintf('                Covariate Effect   \n ')
     fprintf(' ___________________________________ \n')

     for i = 1:length(meanCE)
         fprintf(' %s  % 10.3f  \n', rowlabelsCE(i,:),meanCE(i))
     end

%--------------------------- End of Codes ---------------------------------  

