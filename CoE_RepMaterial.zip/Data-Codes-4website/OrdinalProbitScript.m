
% Ordinal Probit Model

%% Application: Marijuana Study

clear all
clc
[data, text] = xlsread('Feb14Data.xlsx', 'CleanedDataFeb14','A2:L1493');

age            = data(:,1);          % Age of the respondent
logage         = log(age)
nMember        = data(:,6);          % No of members in the household

n              = size(age,1);

ageSummary     = [mean(age) std(age)]
logageSummary  = [mean(logage) std(logage)]
nMemberSummary = [mean(nMember) std(nMember)]

%% Response variable
opinion        = zeros(n,1);
for i = 1:n
    if strcmp(text(i,1),'notlegal');
        opinion(i,1) = 1;
    elseif strcmp(text(i,1),'medicinal');
        opinion(i,1) = 2;
    else strcmp(text(i,1),'personal');   
        opinion(i,1) = 3;                 % favor legalization = 1
    end
end
tabulate(opinion)
%% Covariates

%---------------------------------
% Pastuse
pastuse        = zeros(n,1);              % Used marijuana in the past = 1
for i = 1:n
    if strcmp(text(i,2),'Yes')    
        pastuse(i,1) = 1;                 
    end
end
disp('        Past Use')
disp('----------------------------')
tabulate(pastuse)

%---------------------------------
%% Religion 
religion       = nominal(text(:,3));
% getlevels(religion);


protestant       = zeros(n,1);
romanCatholic    = zeros(n,1);
christian        = zeros(n,1);
conservative     = zeros(n,1);
liberal          = zeros(n,1);

for i = 1:n
    if strcmp(text(i,3),'Protestant (Baptist, Methodist, Non-denominational, Lutheran, Presbyterian, Pentecostal, Episcopalian, Reformed, etc.)')    
        protestant(i,1) = 1;                 
    elseif strcmp(text(i,3),'Roman Catholic (Catholic)') 
        romanCatholic(i,1) = 1;
    elseif strcmp(text(i,3),'Christian (VOL.)') 
        christian(i,1) = 1;    
    elseif strcmp(text(i,3),'Agnostic (not sure if there is a God)')||...
           strcmp(text(i,3),'Atheist (do not believe in God)')||...
           strcmp(text(i,3),'Nothing in particular')||...
           strcmp(text(i,3),'Unitarian (Universalist) (VOL.)');
        liberal(i,1) = 1;
    elseif strcmp(text(i,3),'Buddhist')||strcmp(text(i,3),'Hindu')||...
           strcmp(text(i,3),'Muslim (Islam)')||strcmp(text(i,3),'Jewish (Judaism)')||...
           strcmp(text(i,3),'Mormon (Church of Jesus Christ of Latter-day Saints/LDS)')||...
           strcmp(text(i,3),'Orthodox (Greek, Russian, or some other orthodox church)')
        conservative(i,1) = 1;
    end
end


disp('________ Protestant ________')
tabulate(protestant)

disp('________ Roman Catholic ________')
tabulate(romanCatholic)

disp('________ Christian ________')
tabulate(christian)

disp('________ Conservative ________')
tabulate(conservative)

disp('________ liberal ________')
tabulate(liberal)


%---------------------------------
%% Gender

male            = zeros(n,1);              % Male = 1
for i = 1:n
    if strcmp(text(i,4),'Male')    
        male(i,1) = 1;                 
    end
end
disp('___________  Male ________  ')
tabulate(male)

%---------------------------------
%% Education

education    = text(:,6);
% education    = nominal(education);
% education    = mergelevels(education,{'Less than HS', 'HS Incomplete'},'hsIncomplete');
% education    = mergelevels(education,{'Some college','Associate Degree'},'lessThanBachelors');
% education    = mergelevels(education,{'Postgraduate Degree','Some
% Postgraduate'},'postBachelors');


HSandBelow         = zeros(n,1);
lessThanBachelors  = zeros(n,1);   
BachelorsandAbove  = zeros(n,1);


for i = 1:n
    if strcmp( text(i,6),'Less than HS')||strcmp(text(i,6),'HS Incomplete')||...               
    strcmp(text(i,6),'HS') 
        HSandBelow(i,1) = 1;
    elseif strcmp(text(i,6),'Some College')||strcmp(text(i,6),'Associate Degree')
        lessThanBachelors(i,1) = 1;
    elseif strcmp(text(i,6),'Four year college')||strcmp(text(i,6),'Postgraduate Degree')||strcmp(text(i,6),'Some Postgraduate')
        BachelorsandAbove(i,1) = 1;
    end
end

disp('_____ High School and Below _________')
tabulate(HSandBelow)

disp('_____ less than Bachelors _________')
tabulate(lessThanBachelors)

disp('_____ Bachelors and Above _________')
tabulate(BachelorsandAbove)
%---------------------------------
%% Race

% race    = nominal(race);
% race    = mergelevels(race,{'Asian', 'Hispanic','Native American','Other Race','Pacific Islander'},'AllOther');

race    = text(:,7);
white    = zeros(n,1);
black    = zeros(n,1);
allOther = zeros(n,1);

for i = 1:n
    if strcmp(text(i,7),'White')    
        white(i,1) = 1;                 
    elseif strcmp(text(i,7),'Black or African-American') 
        black(i,1) = 1;
    else
        allOther(i,1) = 1;
    end
end
tabulate(race)

disp('________ White ________')
tabulate(white)

disp('________ Black ________')
tabulate(black)

disp('________ All Other ________')
tabulate(allOther)
%---------------------------------


%% Income as continous variable


incomeC = zeros(n,1);
for i = 1:n

    if strcmp(text(i,8),'Less than $10,000')
        incomeC(i,1)  = 5000;
    elseif strcmp(text(i,8),'10 to under $20,000')
        incomeC(i,1)  = 15000;
    elseif strcmp(text(i,8),'20 to under $30,000')
        incomeC(i,1)  = 25000;
    elseif strcmp(text(i,8),'30 to under $40,000')
        incomeC(i,1)  = 35000;
    elseif strcmp(text(i,8),'40 to under $50,000')
        incomeC(i,1)  = 45000;
    elseif strcmp(text(i,8),'50 to under $75,000')
        incomeC(i,1)  = 63500;
    elseif strcmp(text(i,8),'75 to under $100,000')
        incomeC(i,1)  = 87500;
    elseif strcmp(text(i,8),'100 to under $150,000')
        incomeC(i,1)  = 125000;
    elseif strcmp(text(i,8),'$150,000 or more')
        incomeC(i,1)  = 150000;
    end
end

logIncomeC  = log(incomeC);
unique(logIncomeC)

logIncomeCSummary = [mean(logIncomeC) std(logIncomeC)]
%-------------------------------------------------------------------    
%% Party Affiliation

party              = text(:,9);
democrat           = zeros(n,1);
republican         = zeros(n,1);
independentOthers  = zeros(n,1);    % independent and others

for i = 1:n
    if strcmp(text(i,9),'Democrat')
        democrat(i,1) = 1;                 
    elseif strcmp(text(i,9),'Republican') 
        republican(i,1) = 1;
    elseif strcmp(text(i,9),'Independent')||strcmp(text(i,9),'Other party (VOL.)')...
            ||strcmp(text(i,9),'No preference (VOL.)') 
        independentOthers(i,1) = 1;
    end
end

disp('________ Democrat ________')
tabulate(democrat)

disp('________ Republican ________')
tabulate(republican)

disp('________ Independent and Others ________')
tabulate(independentOthers)


%----------------------------------------------------------------------------------------------------------
%% State

state              = text(:,11);
totalProhibition   = zeros(n,1);
someRelaxation     = zeros(n,1);

for i = 1:n
    if strcmp(text(i,11),'Alabama')||strcmp(text(i,11),'Arkansas')||strcmp(text(i,11),'Florida')...
            ||strcmp(text(i,11),'Georgia')||strcmp(text(i,11),'Idaho')||strcmp(text(i,11),'Indiana')...
            ||strcmp(text(i,11),'Iowa')||strcmp(text(i,11),'Kansas')||strcmp(text(i,11),'Kentucky')...
            ||strcmp(text(i,11),'Louisiana')||strcmp(text(i,11),'Minnesota')||strcmp(text(i,11),'Mississippi')...
            ||strcmp(text(i,11),'Missouri')||strcmp(text(i,11),'Nebraska')||strcmp(text(i,11),'New York')...
            ||strcmp(text(i,11),'North Carolina')||strcmp(text(i,11),'North Dakota')||strcmp(text(i,11),'Ohio')...
            ||strcmp(text(i,11),'Oklahoma')||strcmp(text(i,11),'Pennsylvania')||strcmp(text(i,11),'South Carolina')...
            ||strcmp(text(i,11),'South Dakota')||strcmp(text(i,11),'Tennessee')||strcmp(text(i,11),'Texas')...
            ||strcmp(text(i,11),'Utah')||strcmp(text(i,11),'Virginia')||strcmp(text(i,11),'West Virginia')...
            ||strcmp(text(i,11),'Wisconsin')||strcmp(text(i,11),'Wyoming')
        totalProhibition(i,1)= 1;
        
        
    elseif strcmp(text(i,11),'Alaska')||strcmp(text(i,11),'Arizona')||strcmp(text(i,11),'California')...
            ||strcmp(text(i,11),'Colorado')||strcmp(text(i,11),'Connecticut')||strcmp(text(i,11),'Delaware')...
            ||strcmp(text(i,11),'Hawaii')||strcmp(text(i,11),'Illinois')||strcmp(text(i,11),'Maine')...
            ||strcmp(text(i,11),'Maryland')||strcmp(text(i,11),'Massachusetts')||strcmp(text(i,11),'Michigan')...
            ||strcmp(text(i,11),'Montana')||strcmp(text(i,11),'Nevada')||strcmp(text(i,11),'New Hampshire')...
            ||strcmp(text(i,11),'New Jersey')||strcmp(text(i,11),'New Mexico')||strcmp(text(i,11),'Oregon')...
            ||strcmp(text(i,11),'Rhode Island')||strcmp(text(i,11),'Vermont')||strcmp(text(i,11),'Washington')...
            ||strcmp(text(i,11),'Washington DC')||strcmp(text(i,11),'District of Columbia')
        someRelaxation(i,1)= 1;
    end
end

disp('________ totalProhibition ________')
tabulate(totalProhibition)

disp('________ someRelaxation ________')
tabulate(someRelaxation)

%% Expected Legalization


expectedLegal       = zeros(n,1);              % Male = 1
for i = 1:n
    if strcmp(text(i,12),'Yes, it will')    
        expectedLegal(i,1) = 1;                 
    end
end
disp('___________  Expected Legalization ________  ')
tabulate(expectedLegal)



%--------------------------------------------------------------------------
%% Opinion

y = opinion;

%% Intercept Model

link = 'probit';
K    = length(unique(y));

x0          = ones(n,1);
rowlabels0  = char('cutpoint', 'intercept');

[mle0,cov0,dev0,devRes0,fits0] = ordinalMLE([y x0],K,link);  
% Note: The functin ordinalMLE computes the MLE for ordinal regression. It
% is part of a set of functions provided by Valen E. Johnson for the book, 
% Ordinal Data Modeling.  

betaOrdProbit0     = mle0;
stderrOrdProbit0   = sqrt(diag(cov0));
tvaluesOrdProbit0  = betaOrdProbit0./stderrOrdProbit0;




     fprintf('             Results from Intercept Model   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('                Coeff    Std Err   t-values \n')
     fprintf('              ________  ________  _________ \n')
 
     for i = 1:(K-2)+size(x0,2)
         fprintf(' %-12s  % 4.3f  % 8.2f  % 8.2f  \n', rowlabels0(i,:),...
             betaOrdProbit0(i), stderrOrdProbit0(i), tvaluesOrdProbit0(i))
     end

 
% Finding the Hit Rate i.e. if the observed category has the highest
% probability then it is a hit, otherwise miss.

[outputMax0, indexMax0] = max(fits0,[],2);

hit0 = zeros(n,1);

for i=1:n
    if indexMax0(i,1)==opinion(i,1);
        hit0(i,1) = 1;
    end
end

hitrate0 = (sum(hit0)/n)*100

% Log Likelihood of the Null Model

lnpdf0  = zeros(n,1);
cutpoints0 = [-inf ;0 ; mle0(1); inf];
beta0      = mle0(2);
mu0        = ones(n,1)*beta0;


for i = 1:n
    meani = mu0(i);
    if y(i)==1
        lnpdf0(i) = log( normcdf(0,meani,1));
    elseif y(i)==K
        lnpdf0(i) = log(1 - normcdf(cutpoints0(K),meani,1));
    else
        lnpdf0(i) = log( normcdf( cutpoints0(y(i)+1), meani,1) - ...
                         normcdf( cutpoints0(y(i)), meani,1)    );
    end
end

sumlogLikelihood0  = sum(lnpdf0)


%% Model5

x5   = [ones(n,1) log(age) logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
       nMember someRelaxation expectedLegal];
   
rowlabels5      = char('cutpoint', 'intercept','log age','logIncomeC','pastuse','male',...
                      'BachelorsandAbove','lessThanBachelors','Household Size',...
                      'someRelaxation','expectedLegal');

[mle5,cov5,dev5,devRes5,fits5] = ordinalMLE([y x5],K,link);  

betaOrdProbit5     = mle5;
stderrOrdProbit5   = sqrt(diag(cov5));
tvaluesOrdProbit5  = betaOrdProbit5./stderrOrdProbit5;




     fprintf('             Results from Intercept Model   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('                     Coeff    Std Err   t-values \n')
     fprintf('                   ________  ________  _________ \n')
 
     for i = 1:(K-2)+size(x5,2)
         fprintf(' %-12s  % 4.3f  % 8.2f  % 8.2f  \n', rowlabels5(i,:),...
             betaOrdProbit5(i), stderrOrdProbit5(i), tvaluesOrdProbit5(i))
     end

 
% Finding the Hit Rate i.e. if the observed category has the highest
% probability then it is a hit, otherwise miss.

[outputMax5, indexMax5] = max(fits5,[],2);

hit5 = zeros(n,1);

for i=1:n
    if indexMax5(i,1)==opinion(i,1);
        hit5(i,1) = 1;
    end
end

hitrate5 = (sum(hit5)/n)*100

% LogLikelihood for Model5
%------------------------------

lnpdf5    = zeros(n,1);
cutpoints5 = [-inf ;0 ; mle5(1); inf];
betas5     = mle5(2:11);
mu5        = x5*betas5;


for i = 1:n
    mean5i = mu5(i);
    if y(i)==1
        lnpdf5(i) = log( normcdf(0,mean5i,1));
    elseif y(i)==K
        lnpdf5(i) = log(1 - normcdf(cutpoints5(K),mean5i,1));
    else
        lnpdf5(i) = log( normcdf( cutpoints5(y(i)+1), mean5i,1) - ...
                         normcdf( cutpoints5(y(i)), mean5i,1)    );
    end
end

sumlogLikelihood5  = sum(lnpdf5);


McFaddenRsquare5 = 1 -(sumlogLikelihood5/sumlogLikelihood0)

chisquareTest5   = - 2*(sumlogLikelihood0 - sumlogLikelihood5)

% Compare with chisquare(9) = 16.92

%% Model 6

x6   = [ones(n,1) log(age) logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
       nMember someRelaxation expectedLegal black allOther];
   
rowlabels6      = char('cutpoint', 'intercept','log age','logIncomeC','pastuse','male',...
                      'BachelorsandAbove','lessThanBachelors','Household Size',...
                      'someRelaxation','expectedLegal','black','allOther');

[mle6,cov6,dev6,devRes6,fits6] = ordinalMLE([y x6],K,link);  

betaOrdProbit6     = mle6;
stderrOrdProbit6   = sqrt(diag(cov6));
tvaluesOrdProbit6  = betaOrdProbit6./stderrOrdProbit6;

     fprintf('                      Results from Model6   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('                     Coeff    Std Err   t-values \n')
     fprintf('                   ________  ________  _________ \n')
 
     for i = 1:(K-2)+size(x6,2)
         fprintf(' %-12s  % 4.3f  % 8.2f  % 8.2f  \n', rowlabels6(i,:),...
             betaOrdProbit6(i), stderrOrdProbit6(i), tvaluesOrdProbit6(i))
     end

 
% Finding the Hit Rate i.e. if the observed category has the highest
% probability then it is a hit, otherwise miss.

[outputMax6, indexMax6] = max(fits6,[],2);

hit6 = zeros(n,1);

for i=1:n
    if indexMax6(i,1)==opinion(i,1);
        hit6(i,1) = 1;
    end
end

hitrate6 = (sum(hit6)/n)*100

% LogLikelihood for Model6
%------------------------------

lnpdf6    = zeros(n,1);
cutpoints6 = [-inf ;0 ; mle6(1); inf];
betas6     = mle6(2:13);
mu6        = x6*betas6;


for i = 1:n
    mean6i = mu6(i);
    if y(i)==1
        lnpdf6(i) = log( normcdf(0,mean6i,1));
    elseif y(i)==K
        lnpdf6(i) = log(1 - normcdf(cutpoints6(K),mean6i,1));
    else
        lnpdf6(i) = log( normcdf( cutpoints6(y(i)+1), mean6i,1) - ...
                         normcdf( cutpoints6(y(i)), mean6i,1)    );
    end
end

sumlogLikelihood6  = sum(lnpdf6);

McFaddenRsquare6 = 1 -(sumlogLikelihood6/sumlogLikelihood0)

chisquareTest6   = - 2*(sumlogLikelihood0 - sumlogLikelihood6)

% Compare with chisquare(11) = 19.68

%% Model 7

x7   = [ones(n,1) log(age) logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
       nMember someRelaxation expectedLegal black allOther democrat independentOthers];
   
rowlabels7      = char('cutpoint', 'intercept','log age','logIncomeC','pastuse','male',...
                      'BachelorsandAbove','lessThanBachelors','Household Size',...
                      'someRelaxation','expectedLegal','black','allOther','democrat','OtherParties');

[mle7,cov7,dev7,devRes7,fits7] = ordinalMLE([y x7],K,link);  

betaOrdProbit7     = mle7;
stderrOrdProbit7   = sqrt(diag(cov7));
tvaluesOrdProbit7  = betaOrdProbit7./stderrOrdProbit7;




     fprintf('                     Results from Model7   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('                     Coeff    Std Err   t-values \n')
     fprintf('                   ________  ________  _________ \n')
 
     for i = 1:(K-2)+size(x7,2)
         fprintf(' %-12s  % 4.3f  % 8.2f  % 8.2f  \n', rowlabels7(i,:),...
             betaOrdProbit7(i), stderrOrdProbit7(i), tvaluesOrdProbit7(i))
     end

 
% Finding the Hit Rate i.e. if the observed category has the highest
% probability then it is a hit, otherwise miss.

[outputMax7, indexMax7] = max(fits7,[],2);

hit7 = zeros(n,1);

for i=1:n
    if indexMax7(i,1)==opinion(i,1);
        hit7(i,1) = 1;
    end
end

hitrate7 = (sum(hit7)/n)*100

% LogLikelihood for Model7
%------------------------------

lnpdf7     = zeros(n,1);
cutpoints7 = [-inf ;0 ; mle7(1); inf];
betas7     = mle7(2:15);
mu7        = x7*betas7;


for i = 1:n
    mean7i = mu7(i);
    if y(i)==1
        lnpdf7(i) = log( normcdf(0,mean7i,1));
    elseif y(i)==K
        lnpdf7(i) = log(1 - normcdf(cutpoints7(K),mean7i,1));
    else
        lnpdf7(i) = log( normcdf( cutpoints7(y(i)+1), mean7i,1) - ...
                         normcdf( cutpoints7(y(i)), mean7i,1)    );
    end
end

sumlogLikelihood7  = sum(lnpdf7);

McFaddenRsquare7 = 1 -(sumlogLikelihood7/sumlogLikelihood0)

chisquareTest7   = - 2*(sumlogLikelihood0 - sumlogLikelihood7)

% Compare with chisquare(13) = 22.36

%% Model 8

x8   = [ones(n,1) log(age) logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
       nMember someRelaxation expectedLegal black allOther democrat independentOthers ...
       romanCatholic christian conservative liberal ];
   
rowlabels8      = char('cutpoint', 'intercept','log age','logIncomeC','pastuse','male',...
                      'BachelorsandAbove','lessThanBachelors','Household Size',...
                      'someRelaxation','expectedLegal','black','allOther','democrat','OtherParties',...
                      'romanCatholic','christian','conservative','liberal');

[mle8,cov8,dev8,devRes8,fits8] = ordinalMLE([y x8],K,link);  

betaOrdProbit8     = mle8;
stderrOrdProbit8   = sqrt(diag(cov8));
tvaluesOrdProbit8  = betaOrdProbit8./stderrOrdProbit8;




     fprintf('                        Results from Model8   \n ')
     fprintf('________________________________________________________ \n')
     fprintf('                     Coeff    Std Err   t-values \n')
     fprintf('                   ________  ________  _________ \n')
 
     for i = 1:(K-2)+size(x8,2)
         fprintf(' %-12s  % 4.3f  % 8.2f  % 8.2f  \n', rowlabels8(i,:),...
             betaOrdProbit8(i), stderrOrdProbit8(i), tvaluesOrdProbit8(i))
     end

 
% Finding the Hit Rate i.e. if the observed category has the highest
% probability then it is a hit, otherwise miss.

[outputMax8, indexMax8] = max(fits8,[],2);

hit8 = zeros(n,1);

for i=1:n
    if indexMax8(i,1)==opinion(i,1);
        hit8(i,1) = 1;
    end
end

hitrate8 = (sum(hit8)/n)*100

% LogLikelihood for Model8
%------------------------------

lnpdf8     = zeros(n,1);
cutpoints8 = [-inf ;0 ; mle8(1); inf];
betas8     = mle8(2:19);
mu8        = x8*betas8;


for i = 1:n
    mean8i = mu8(i);
    if y(i)==1
        lnpdf8(i) = log( normcdf(0,mean8i,1));
    elseif y(i)==K
        lnpdf8(i) = log(1 - normcdf(cutpoints8(K),mean8i,1));
    else
        lnpdf8(i) = log( normcdf( cutpoints8(y(i)+1), mean8i,1) - ...
                         normcdf( cutpoints8(y(i)), mean8i,1)    );
    end
end

sumlogLikelihood8  = sum(lnpdf8);

McFaddenRsquare8 = 1 -(sumlogLikelihood8/sumlogLikelihood0)

chisquareTest8   = - 2*(sumlogLikelihood0 - sumlogLikelihood8)

% Compare with chisquare(17) = 27.59


     
%% Covariate Effects
%--------------------------------------------------------------------------

% (1) Covariate effect for logage

% x8   = [ones(n,1) log(age) logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
%        nMember someRelaxation expectedLegal black allOther democrat independentOthers ...
%        romanCatholic christian conservative liberal ];
   

cutpoints = [-inf ;0 ; mle8(1); inf];
betas     = mle8(2:size(x8,2)+1);

newAge   = [ ones(n,1) log(age+10) logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
             nMember someRelaxation expectedLegal black allOther ...
             democrat independentOthers romanCatholic christian conservative liberal];
             
oldAge   = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
             nMember someRelaxation expectedLegal black allOther ...
             democrat independentOthers romanCatholic christian conservative liberal];
                 
oldProbsAge = zeros(K,n);
newProbsAge = zeros(K,n);

for i=1:n
for k=1:K
    oldProbsAge(k,i) = normcdf(cutpoints(k+1)-oldAge(i,:)*betas,0,1) ...
                  - normcdf(cutpoints(k)-oldAge(i,:)*betas,0,1);
    newProbsAge(k,i) = normcdf(cutpoints(k+1)-newAge(i,:)*betas,0,1) ...
                  - normcdf(cutpoints(k)-newAge(i,:)*betas,0,1);
end
end

meanAgeCE = mean(newProbsAge,2) - mean(oldProbsAge,2);


%%
% (2) Covariate Effect for logIncome

newIncome   = [ones(n,1) logage log(incomeC+10000) pastuse male BachelorsandAbove lessThanBachelors ...
               nMember someRelaxation expectedLegal black allOther ...
               democrat independentOthers romanCatholic christian conservative liberal];
         
oldIncome   = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
             nMember someRelaxation expectedLegal black allOther ...
             democrat independentOthers romanCatholic christian conservative liberal];

oldProbsIncome = zeros(K,n);
newProbsIncome = zeros(K,n);

for i=1:n
for k=1:K
    oldProbsIncome(k,i) = normcdf(cutpoints(k+1)-oldIncome(i,:)*betas,0,1) ...
                          - normcdf(cutpoints(k)-oldIncome(i,:)*betas,0,1);
    newProbsIncome(k,i) = normcdf(cutpoints(k+1)-newIncome(i,:)*betas,0,1) ...
                          - normcdf(cutpoints(k)-newIncome(i,:)*betas,0,1);
end
end

meanIncomeCE = mean(newProbsIncome,2) - mean(oldProbsIncome,2);

%% Covariate Effect for Past Use

% (3) Change in probability for Past Use

xPastUse   = [ ones(n,1) logage logIncomeC ones(n,1) male BachelorsandAbove lessThanBachelors ...
             nMember someRelaxation expectedLegal black allOther ...
             democrat independentOthers romanCatholic christian conservative liberal];
         
xNoPastUse = [ ones(n,1) logage logIncomeC zeros(n,1) male BachelorsandAbove lessThanBachelors ...
             nMember someRelaxation expectedLegal black allOther ...
             democrat independentOthers romanCatholic christian conservative liberal];

oldProbsPU = zeros(K,n);
newProbsPU = zeros(K,n);

for i=1:n
for k=1:K
    oldProbsPU(k,i) = normcdf(cutpoints(k+1)-xNoPastUse(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xNoPastUse(i,:)*betas,0,1);
    newProbsPU(k,i) = normcdf(cutpoints(k+1)-xPastUse(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xPastUse(i,:)*betas,0,1);
end
end

meanPastUseCE = mean(newProbsPU,2) - mean(oldProbsPU,2);

%% Covariate Effect for Bachelors and Above

% (4) Change in probability for Bachelors and Above

xBachelorsandAbove =  [ones(n,1) logage logIncomeC pastuse male ones(n,1) lessThanBachelors ...
                       nMember someRelaxation expectedLegal black allOther ...
                       democrat independentOthers romanCatholic christian conservative liberal];
         
xBaseEduc = [ones(n,1) logage logIncomeC pastuse male zeros(n,1) lessThanBachelors ...
             nMember someRelaxation expectedLegal black allOther ...
             democrat independentOthers romanCatholic christian conservative liberal];

oldProbsBachelorsandAbove = zeros(K,n);
newProbsBachelorsandAbove = zeros(K,n);

for i=1:n
for k=1:K
    oldProbsBachelorsandAbove(k,i) = normcdf(cutpoints(k+1)-xBaseEduc(i,:)*betas,0,1) ...
                                - normcdf(cutpoints(k)-xBaseEduc(i,:)*betas,0,1);
    newProbsBachelorsandAbove(k,i) = normcdf(cutpoints(k+1)-xBachelorsandAbove(i,:)*betas,0,1) ...
                                - normcdf(cutpoints(k)-xBachelorsandAbove(i,:)*betas,0,1);
end
end

meanBachelorsandAboveCE = mean(newProbsBachelorsandAbove,2) - mean(oldProbsBachelorsandAbove,2);

%% Covariate Effect for Eventually Legal

% (5) Change in probability for Expected Legalization

xExpLegal   = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                nMember someRelaxation ones(n,1) black allOther ...
                democrat independentOthers romanCatholic christian conservative liberal];
         
xNotExpLegal = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                 nMember someRelaxation zeros(n,1) black allOther ...
                 democrat independentOthers romanCatholic christian conservative liberal];

oldProbsEL = zeros(K,n);
newProbsEL = zeros(K,n);

for i=1:n
for k=1:K
    newProbsEL(k,i) = normcdf(cutpoints(k+1)-xExpLegal(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xExpLegal(i,:)*betas,0,1);
    oldProbsEL(k,i) = normcdf(cutpoints(k+1)-xNotExpLegal(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xNotExpLegal(i,:)*betas,0,1);

end
end

meanExpectedLegalCE = mean(newProbsEL,2) - mean(oldProbsEL,2);

%% Covariate Effect for Other Races

% (6) Change in probability for other races relative to white

xOtherRaces  = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
             nMember someRelaxation expectedLegal black ones(n,1) ...
             democrat independentOthers romanCatholic christian conservative liberal];
         
xNotOtherRaces  = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
            nMember someRelaxation expectedLegal black zeros(n,1) ...
            democrat independentOthers romanCatholic christian conservative liberal];

ProbsOtherRaces = zeros(K,n);
ProbsNotOtherRaces = zeros(K,n);

for i=1:n
for k=1:K
    ProbsOtherRaces(k,i) =  normcdf(cutpoints(k+1)-xOtherRaces(i,:)*betas,0,1) ...
                       - normcdf(cutpoints(k)-xOtherRaces(i,:)*betas,0,1);
    ProbsNotOtherRaces(k,i)   =  normcdf(cutpoints(k+1)-xNotOtherRaces(i,:)*betas,0,1) ...
                       - normcdf(cutpoints(k)-xNotOtherRaces(i,:)*betas,0,1);
end
end

meanOtherRacesCE = mean(ProbsOtherRaces,2) - mean(ProbsNotOtherRaces,2);


%% Covariate Effect for Political Affiliation

% (7) Change in probability for Democrat

xDemocrat   = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                nMember someRelaxation expectedLegal black allOther ...
                ones(n,1) independentOthers romanCatholic christian conservative liberal];
         
xNotDemocrat = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                 nMember someRelaxation expectedLegal black allOther ...
                 zeros(n,1) independentOthers romanCatholic christian conservative liberal];

oldProbsD = zeros(K,n);
newProbsD = zeros(K,n);

for i=1:n
for k=1:K
    newProbsD(k,i) = normcdf(cutpoints(k+1)-xDemocrat(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xDemocrat(i,:)*betas,0,1);
    oldProbsD(k,i) = normcdf(cutpoints(k+1)-xNotDemocrat(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xNotDemocrat(i,:)*betas,0,1);

end
end

meanDemocratCE = mean(newProbsD,2) - mean(oldProbsD,2);

% (8) Change in probability for Other Parties

xOtherParties   = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                    nMember someRelaxation expectedLegal black allOther ...
                    democrat ones(n,1) romanCatholic christian conservative liberal];
         
xNotOtherParties = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                   nMember someRelaxation expectedLegal black allOther ...
                   democrat zeros(n,1) romanCatholic christian conservative liberal];

oldProbsR = zeros(K,n);
newProbsR = zeros(K,n);

for i=1:n
for k=1:K
    newProbsR(k,i) = normcdf(cutpoints(k+1)-xOtherParties(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xOtherParties(i,:)*betas,0,1);
    oldProbsR(k,i) = normcdf(cutpoints(k+1)-xNotOtherParties(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xNotOtherParties(i,:)*betas,0,1);

end
end

meanOtherPartiesCE = mean(newProbsR,2) - mean(oldProbsR,2);

%% Covariate Effect for Religion

% (9)  Change in probability for Liberal

xLiberal   = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
               nMember someRelaxation expectedLegal black allOther ...
               democrat independentOthers romanCatholic christian conservative ones(n,1)];
         
xNotLiberal = [ ones(n,1) logage logIncomeC pastuse male BachelorsandAbove lessThanBachelors ...
                nMember someRelaxation expectedLegal black allOther ...
                democrat independentOthers romanCatholic christian conservative zeros(n,1)];

oldProbsTS = zeros(K,n);
newProbsTS = zeros(K,n);

for i=1:n
for k=1:K
    newProbsTS(k,i) = normcdf(cutpoints(k+1)-xLiberal(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xLiberal(i,:)*betas,0,1);
    oldProbsTS(k,i) = normcdf(cutpoints(k+1)-xNotLiberal(i,:)*betas,0,1) ...
                      - normcdf(cutpoints(k)-xNotLiberal(i,:)*betas,0,1);

end
end

meanLiberalCE = mean(newProbsTS,2) - mean(oldProbsTS,2);


%% Covariate Effects in a Table
%--------------------------------------------------------------------------

rowlabelsCE  = char('Age 5 years', 'Income 10000', 'Past Use',...
              'Bachelors and Above','Eventually Legal','Other Races',...
              'Democrat','Other Parties','Liberal');
                  
meanCE = [meanAgeCE meanIncomeCE meanPastUseCE meanBachelorsandAboveCE ...
          meanExpectedLegalCE meanOtherRacesCE meanDemocratCE meanOtherPartiesCE meanLiberalCE]';

                  
     fprintf('             Results from Ordinal Probit Model           \n')
     fprintf('________________________________________________________ \n')
     fprintf('                       P(y=1)  P(y=2)  P(y=3)          \n')
     fprintf('                       _____   _____   _____        \n')
 
     for i = 1:length(meanCE)
         fprintf(' % -12s  % 4.3f  % 4.3f  % 4.3f  \n', rowlabelsCE(i,:),...
                 meanCE(i,1), meanCE(i,2), meanCE(i,3))
     end

%--------------------------- End of Codes ---------------------------------  


